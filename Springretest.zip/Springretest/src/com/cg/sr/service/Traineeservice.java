package com.cg.sr.service;

import com.cg.sr.bean.TraineeBean;

public interface Traineeservice {
	
	public TraineeBean addTrainee(TraineeBean traineebean);

}
