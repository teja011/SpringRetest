package com.cg.sr.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="traineem")
public class TraineeBean {
	@Id
	private int traineeid;
	private String traineename;
	private String traineelocation;
	private String domain;
	public int getTraineeid() {
		return traineeid;
	}
	public void setTraineeid(int traineeid) {
		this.traineeid = traineeid;
	}
	public String getTraineename() {
		return traineename;
	}
	public void setTraineename(String traineename) {
		this.traineename = traineename;
	}
	public String getTraineelocation() {
		return traineelocation;
	}
	public void setTraineelocation(String traineelocation) {
		this.traineelocation = traineelocation;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	@Override
	public String toString() {
		return "TraineeBean [traineeid=" + traineeid + ", traineename=" + traineename + ", traineelocation="
				+ traineelocation + ", domain=" + domain + "]";
	}
	
	

}
