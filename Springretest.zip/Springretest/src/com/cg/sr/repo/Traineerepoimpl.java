package com.cg.sr.repo;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.sr.bean.TraineeBean;
@Repository
public class Traineerepoimpl implements Traineerepo {
	
	@PersistenceContext
	EntityManager manager;

	@Override
	public TraineeBean addtrainee(TraineeBean traineebean) {
		
		manager.persist(traineebean);
		manager.flush();
		return traineebean;
	}

}
